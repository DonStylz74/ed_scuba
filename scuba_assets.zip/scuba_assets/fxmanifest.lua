fx_version 'cerulean'
use_fxv2_oal 'yes'
lua54        'yes'
game 'gta5'